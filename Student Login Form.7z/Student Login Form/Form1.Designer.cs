﻿namespace Student_Login_Form
{
    partial class ForStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.RadMale = new System.Windows.Forms.RadioButton();
            this.RadEnrgineer = new System.Windows.Forms.RadioButton();
            this.RarFamale = new System.Windows.Forms.RadioButton();
            this.textName = new System.Windows.Forms.TextBox();
            this.textPassword = new System.Windows.Forms.TextBox();
            this.textEmail = new System.Windows.Forms.TextBox();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.buSend = new System.Windows.Forms.Button();
            this.TextLabal = new System.Windows.Forms.Label();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.ComCountry = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.coloDialog = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(34, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(34, 427);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(195, 34);
            this.label2.TabIndex = 1;
            this.label2.Text = "Date Of Pirth :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(34, 299);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 34);
            this.label3.TabIndex = 2;
            this.label3.Text = "General";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(34, 215);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 34);
            this.label4.TabIndex = 3;
            this.label4.Text = "Password :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(34, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 34);
            this.label5.TabIndex = 4;
            this.label5.Text = "Email :";
            // 
            // RadMale
            // 
            this.RadMale.AutoSize = true;
            this.RadMale.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RadMale.Location = new System.Drawing.Point(120, 357);
            this.RadMale.Name = "RadMale";
            this.RadMale.Size = new System.Drawing.Size(98, 38);
            this.RadMale.TabIndex = 4;
            this.RadMale.TabStop = true;
            this.RadMale.Text = "Male";
            this.RadMale.UseVisualStyleBackColor = true;
            // 
            // RadEnrgineer
            // 
            this.RadEnrgineer.AutoSize = true;
            this.RadEnrgineer.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RadEnrgineer.Location = new System.Drawing.Point(472, 357);
            this.RadEnrgineer.Name = "RadEnrgineer";
            this.RadEnrgineer.Size = new System.Drawing.Size(159, 38);
            this.RadEnrgineer.TabIndex = 6;
            this.RadEnrgineer.TabStop = true;
            this.RadEnrgineer.Text = "Enrgineer";
            this.RadEnrgineer.UseVisualStyleBackColor = true;
            // 
            // RarFamale
            // 
            this.RarFamale.AutoSize = true;
            this.RarFamale.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RarFamale.Location = new System.Drawing.Point(283, 357);
            this.RarFamale.Name = "RarFamale";
            this.RarFamale.Size = new System.Drawing.Size(130, 38);
            this.RarFamale.TabIndex = 5;
            this.RarFamale.TabStop = true;
            this.RarFamale.Text = "Famale";
            this.RarFamale.UseVisualStyleBackColor = true;
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(219, 47);
            this.textName.Multiline = true;
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(283, 43);
            this.textName.TabIndex = 1;
            // 
            // textPassword
            // 
            this.textPassword.Location = new System.Drawing.Point(219, 215);
            this.textPassword.Multiline = true;
            this.textPassword.Name = "textPassword";
            this.textPassword.PasswordChar = '*';
            this.textPassword.Size = new System.Drawing.Size(283, 43);
            this.textPassword.TabIndex = 3;
            // 
            // textEmail
            // 
            this.textEmail.Location = new System.Drawing.Point(219, 131);
            this.textEmail.Multiline = true;
            this.textEmail.Name = "textEmail";
            this.textEmail.Size = new System.Drawing.Size(283, 43);
            this.textEmail.TabIndex = 2;
            this.textEmail.TextChanged += new System.EventHandler(this.textEmail_TextChanged_1);
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(250, 433);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(277, 27);
            this.dateTimePicker.TabIndex = 7;
            // 
            // buSend
            // 
            this.buSend.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buSend.Location = new System.Drawing.Point(120, 613);
            this.buSend.Name = "buSend";
            this.buSend.Size = new System.Drawing.Size(217, 45);
            this.buSend.TabIndex = 9;
            this.buSend.Text = "Send";
            this.buSend.UseVisualStyleBackColor = true;
            this.buSend.Click += new System.EventHandler(this.buSend_Click);
            // 
            // TextLabal
            // 
            this.TextLabal.AutoSize = true;
            this.TextLabal.BackColor = System.Drawing.Color.Silver;
            this.TextLabal.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextLabal.Location = new System.Drawing.Point(781, 313);
            this.TextLabal.Name = "TextLabal";
            this.TextLabal.Size = new System.Drawing.Size(265, 34);
            this.TextLabal.TabIndex = 10;
            this.TextLabal.Text = "Information Student";
            // 
            // colorDialog
            // 
            this.colorDialog.Color = System.Drawing.Color.IndianRed;
            this.colorDialog.FullOpen = true;
            // 
            // ComCountry
            // 
            this.ComCountry.FormattingEnabled = true;
            this.ComCountry.Items.AddRange(new object[] {
            "Yemen ",
            "Oman ",
            "Qater",
            "Syria",
            "SAR",
            "Anther"});
            this.ComCountry.Location = new System.Drawing.Point(250, 498);
            this.ComCountry.Name = "ComCountry";
            this.ComCountry.Size = new System.Drawing.Size(277, 27);
            this.ComCountry.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(34, 491);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 34);
            this.label7.TabIndex = 15;
            this.label7.Text = "Country :";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Tahoma", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.ForeColor = System.Drawing.Color.Green;
            this.label.Location = new System.Drawing.Point(750, 241);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(356, 39);
            this.label.TabIndex = 16;
            this.label.Text = "Inserted Information";
            // 
            // coloDialog
            // 
            this.coloDialog.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coloDialog.Location = new System.Drawing.Point(472, 610);
            this.coloDialog.Name = "coloDialog";
            this.coloDialog.Size = new System.Drawing.Size(205, 48);
            this.coloDialog.TabIndex = 17;
            this.coloDialog.Text = "ColorDialog";
            this.coloDialog.UseVisualStyleBackColor = true;
            this.coloDialog.Click += new System.EventHandler(this.button1_Click);
            // 
            // ForStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1148, 688);
            this.Controls.Add(this.coloDialog);
            this.Controls.Add(this.label);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.ComCountry);
            this.Controls.Add(this.TextLabal);
            this.Controls.Add(this.buSend);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.textEmail);
            this.Controls.Add(this.textPassword);
            this.Controls.Add(this.textName);
            this.Controls.Add(this.RarFamale);
            this.Controls.Add(this.RadEnrgineer);
            this.Controls.Add(this.RadMale);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ForStudent";
            this.Text = "Student Login Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton RadMale;
        private System.Windows.Forms.RadioButton RadEnrgineer;
        private System.Windows.Forms.RadioButton RarFamale;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.TextBox textPassword;
        private System.Windows.Forms.TextBox textEmail;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Button buSend;
        private System.Windows.Forms.Label TextLabal;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.ComboBox ComCountry;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Button coloDialog;
    }
}

