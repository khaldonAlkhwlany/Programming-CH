﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Login_Form
{
    public partial class ForStudent : Form
    {
        public string Email { get; private set; }

        public ForStudent()
        {
            InitializeComponent();
           //Initialization(GetDateTimePicker()); // Initialize components properly
            
        }

        private bool IsValidEmail(string email)
        {
            string pattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, pattern);
        }

        private DateTimePicker GetDateTimePicker() => dateTimePicker;
        private DateTimePicker GetDateTimePicker(DateTimePicker dateTimePicker) => dateTimePicker;

        private void Initialization(DateTimePicker dateTimePicker)
        {
            textName.Text = "";
            textEmail.Text = "";
            textPassword.Text = "";
            dateTimePicker.Value =DateTime.Now ; 
            ComCountry.Text = "Yemen";
        }

        private void buSend_Click(object sender, EventArgs e)
        {
            // Validate empty fields
            if (!string.IsNullOrEmpty(textName.Text) &&
                !string.IsNullOrEmpty(textEmail.Text) &&
                !string.IsNullOrEmpty(textPassword.Text )&&
                !string.IsNullOrEmpty(dateTimePicker.Text) &&
                !string.IsNullOrEmpty(ComCountry.Text) 
                )
            {
                // Validate email format
                if (!IsValidEmail(textEmail.Text))
                {
                    MessageBox.Show("Please enter a valid email address", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                var Name = textName.Text;
                var Email = textEmail.Text;
                var Password = new String('*', textPassword.TextLength);
                var General = RadMale.Checked ? "Male" :
                    RarFamale.Checked ? "Female" : "Engineer";
                var Date = dateTimePicker.Value.ToString("yyyy/MM/dd");
                var country = ComCountry.SelectedItem?.ToString() ??"Unknown";
                

                TextLabal.Text = $"Name: { Name}"+Environment.NewLine ;
                TextLabal.Text += $"Email: {Email}" + Environment.NewLine;
                TextLabal.Text += $"Password: {Password}" + Environment.NewLine;
                TextLabal.Text += $"General:{General}\n ";
                TextLabal.Text += $"Date: {Date} \n ";
                TextLabal.Text += $"country: {country}" + Environment.NewLine;

                Initialization(GetDateTimePicker(GetDateTimePicker()));
              
            }
            else
            {
                MessageBox.Show("Please fill all required fields", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void TextEmail_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textEmail_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog=new ColorDialog();

            if(colorDialog.ShowDialog() == DialogResult.OK)
            {
                TextLabal.BackColor=colorDialog.Color;
            }
            colorDialog.ShowDialog();
        }
    }
}

